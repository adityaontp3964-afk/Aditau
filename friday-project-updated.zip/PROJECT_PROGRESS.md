# PROJECT_PROGRESS.md — FRIDAY 2.0 upgrade

## Status: PHASE 1 (audit) done, PHASE 2 (stabilise) partly done. Build NOT verified.
No Gradle/Android SDK/network in the authoring sandbox. Nothing was compiled or unit-tested here (parser logic was mirror-tested in Python only). First real compile = GitHub Actions.

## Audit (existing project, preserved)
Single module `:app`, package `com.jarvis.assistant`, Compose UI, Vosk offline + Android online STT, Tts, AccessibilityService, Groq-compatible AiClient (+ ActionPlanner allowlist), CommandParser/Dispatcher/WhatsAppController, SharedPreferences settings, SecretStore. ~4,000 lines. Earlier PROGRESS.md also says never compiled.

## Done this session (files modified)
- `command/CommandParser.kt`: new `cleanMessageText`; WhatsApp message payload now stripped of command words ("message", "bhejo", "par", ...) and original capitalisation restored. Fixes "Message Hello" / "par kal milte hain message bhejo" cases.
- `voice/VoiceService.kt`: continuous session. After every reply (and on silence) Friday keeps listening for 25 s (`SESSION_IDLE_MS`) instead of returning to wake-wait/stopping immediately.
- `test/CommandParserTest.kt`: added whatsappPayloadHasNoCommandWords.
- `.github/workflows/build.yml` renamed to `android-build.yml`.

## Known gaps (NOT done): Modules 2-5 (emotion, Room memory, provider abstraction, formal state machine), 6 (Developer Options intent, capability detection), 8 (task queue), 9, 10-12 (new UI/customization/screens), configurable timeout setting.

## Exact next step
Run the Actions build, fix compile errors, then Phase 6: add Developer Options (`Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS`) to `CommandParser`/`CommandDispatcher`, then the configurable session timeout in `Prefs`.
