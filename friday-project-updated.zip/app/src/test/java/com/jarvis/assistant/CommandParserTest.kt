package com.jarvis.assistant

import com.jarvis.assistant.command.Cmd
import com.jarvis.assistant.command.CommandParser
import com.jarvis.assistant.command.Normalizer
import com.jarvis.assistant.command.WakeMatcher
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CommandParserTest {
    @Test fun opensApp() {
        assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("YouTube khol"))
        assertEquals(Cmd.OpenApp("whatsapp"), CommandParser.parse("open whatsapp"))
    }
    @Test fun youtubeSearch() {
        assertEquals(Cmd.YouTubeSearch("arijit singh songs"), CommandParser.parse("youtube par arijit singh songs"))
    }
    @Test fun webSearch() {
        assertEquals(Cmd.WebSearch("weather today"), CommandParser.parse("search weather today"))
        assertTrue(CommandParser.parse("search") is Cmd.MissingArg)
    }
    @Test fun whatsapp() {
        assertEquals(Cmd.WhatsApp("rahul", "hello kaise ho"), CommandParser.parse("rahul ko message bhejo hello kaise ho"))
        assertEquals(Cmd.WhatsApp("rahul", "hi"), CommandParser.parse("send message to rahul hi"))
    }
    @Test fun settingsTimeNames() {
        assertEquals(Cmd.OpenSettings("wifi"), CommandParser.parse("wifi settings kholo"))
        assertEquals(Cmd.TellTime, CommandParser.parse("abhi time kya hua"))
        assertEquals(Cmd.AskName, CommandParser.parse("tumhara naam kya hai"))
        assertEquals(Cmd.AskUserName, CommandParser.parse("mera naam kya hai"))
    }
    @Test fun confirmations() {
        assertEquals(Cmd.Yes, CommandParser.parse("haan"))
        assertEquals(Cmd.No, CommandParser.parse("nahi"))
    }
    @Test fun wake() {
        assertTrue(WakeMatcher.matches("hey jarvis", "hey jarvis"))
        assertTrue(WakeMatcher.matches("hello jar vis", "hey jarvis"))
        assertFalse(WakeMatcher.matches("good morning", "hey jarvis"))
    }
    @Test fun misheardYoutube() {
        assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("open you do"))
        assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("you tube khol"))
        assertEquals(Cmd.OpenApp("whatsapp"), CommandParser.parse("open what s up"))
    }

    @Test fun wakeFriday() {
        assertTrue(WakeMatcher.matches("hey friday", "hey friday"))
        assertTrue(WakeMatcher.matches("hello fry day", "hey friday"))
        assertFalse(WakeMatcher.matches("good morning", "hey friday"))
    }
    @Test fun customWakePhrase() {
        assertTrue(WakeMatcher.matches("ok computer", "ok computer"))
        assertFalse(WakeMatcher.matches("good morning", "ok computer"))
        assertNull(WakeMatcher.validate("hey friday"))
        assertNotNull(WakeMatcher.validate("a1"))
        assertNotNull(WakeMatcher.validate("one two three four five"))
    }
    @Test fun contextAwareAliases() {
        assertEquals("what do you do", Normalizer.normalize("what do you do"))
        assertEquals("i love you too", Normalizer.normalize("I love you too"))
        assertEquals("open youtube", Normalizer.normalize("open you do"))
        assertEquals("youtube khol", Normalizer.normalize("YouTube coal"))
        assertEquals("coal mining", Normalizer.normalize("coal mining"))
        assertEquals("youtube khol", Normalizer.normalize("hey friday youtube kholo"))
    }
    @Test fun hinglishCommands() {
        assertEquals(Cmd.OpenApp("youtube"), CommandParser.parse("YouTube kholo"))
        assertEquals(Cmd.YouTubeSearch("song"), CommandParser.parse("YouTube par song chalao"))
        assertEquals(Cmd.OpenApp("settings"), CommandParser.parse("Settings open karo"))
        assertEquals(Cmd.TellTime, CommandParser.parse("Mujhe time batao"))
        assertEquals(Cmd.Volume(1), CommandParser.parse("Volume badhao"))
        assertEquals(Cmd.Volume(-1), CommandParser.parse("awaaz kam karo"))
        assertEquals(Cmd.Torch(true), CommandParser.parse("Torch on karo"))
        assertEquals(Cmd.Torch(false), CommandParser.parse("torch band karo"))
        assertEquals(Cmd.OpenSettings("wifi"), CommandParser.parse("Wi-Fi settings kholo"))
        assertEquals(Cmd.OpenSettings("sound"), CommandParser.parse("volume settings kholo"))
    }

    @Test fun newPhoneControlCommands() {
        assertEquals(Cmd.Recents, CommandParser.parse("Recent apps kholo"))
        assertEquals(Cmd.Scroll(true), CommandParser.parse("Neeche scroll karo"))
        assertEquals(Cmd.Scroll(false), CommandParser.parse("Upar scroll kar"))
        assertEquals(Cmd.Refresh, CommandParser.parse("Page refresh karo"))
        assertEquals(Cmd.ClearText, CommandParser.parse("Text clear karo"))
        assertEquals(Cmd.Submit, CommandParser.parse("Search karo"))
        assertEquals(Cmd.Dictate, CommandParser.parse("Jo text main bolun use type karo"))
        assertEquals(Cmd.TypeText("Hello"), CommandParser.parse("Search box mein Hello likho"))
    }
    @Test fun whatsAppConversationCommands() {
        assertEquals(Cmd.WhatsAppOpenChat("Kartavya"), CommandParser.parse("Kartavya ki chat kholo"))
        assertEquals(Cmd.WhatsAppOpenChat("Kartavya"), CommandParser.parse("WhatsApp mein Kartavya ki chat open karo"))
        assertEquals(Cmd.WhatsAppToContext("Hi"), CommandParser.parse("Usko Hi message bhejo"))
        assertEquals(Cmd.WhatsAppToContext(null), CommandParser.parse("Usko ek message bhejna hai"))
        assertEquals(Cmd.WhatsApp("Kartavya", "Hi"), CommandParser.parse("Kartavya ko Hi message bhejo"))
        assertEquals(Cmd.WhatsApp("rahul", "hello kaise ho"), CommandParser.parse("rahul ko message bhejo hello kaise ho"))
    }

    @Test fun whatsappPayloadHasNoCommandWords() {
        assertEquals(Cmd.WhatsApp("Rahul", "Hello"), CommandParser.parse("Friday, Rahul ko message karo Hello."))
        assertEquals(Cmd.WhatsApp("Rahul", "Kal milte hain"), CommandParser.parse("Friday, Rahul ko WhatsApp par Kal milte hain message bhejo."))
        assertEquals(Cmd.WhatsApp("Rahul", "Hello"), CommandParser.parse("Rahul ko Hello message bhejo"))
    }
}

