package com.jarvis.assistant.ai

import com.jarvis.assistant.command.ActionPlanner
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Minimal client for any OpenAI-compatible /chat/completions endpoint (Groq, local server, self-hosted...). Uses the endpoint, key and model already saved in Settings. */
object AiClient {
    /** Plain conversation (unchanged behaviour). */
    suspend fun chat(
        endpoint: String, apiKey: String, model: String, userName: String,
        turns: List<Pair<String, String>>, userText: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val system = "You are FRIDAY, a concise voice assistant. Reply in the user's language (Hindi/Hinglish/English) in at most two short sentences." +
                if (userName.isNotBlank()) " Address the user as $userName." else ""
            post(endpoint, apiKey, model, buildMessages(system, turns, userText), null)
        }
    }

    /**
     * Conversation + structured action request. The model replies with one JSON object (see [ActionPlanner]);
     * the caller validates it against the allowlist before anything is executed. Same endpoint/key/model as [chat].
     */
    suspend fun plan(
        endpoint: String, apiKey: String, model: String, userName: String,
        turns: List<Pair<String, String>>, userText: String, context: String
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val system = ActionPlanner.SYSTEM_PROMPT +
                (if (userName.isNotBlank()) "\nAddress the user as $userName in CHAT replies." else "") +
                "\nCurrent context (JSON): $context"
            post(endpoint, apiKey, model, buildMessages(system, turns, userText), 0.2)
        }
    }

    private fun buildMessages(system: String, turns: List<Pair<String, String>>, userText: String): JSONArray {
        val msgs = JSONArray()
        msgs.put(JSONObject().put("role", "system").put("content", system))
        turns.forEach {
            msgs.put(JSONObject().put("role", "user").put("content", it.first))
            msgs.put(JSONObject().put("role", "assistant").put("content", it.second))
        }
        msgs.put(JSONObject().put("role", "user").put("content", userText))
        return msgs
    }

    /** The API key is only ever placed in the Authorization header: never logged, never put in an error message. */
    private fun post(endpoint: String, apiKey: String, model: String, msgs: JSONArray, temperature: Double?): String {
        val body = JSONObject().put("messages", msgs).apply {
            if (model.isNotBlank()) put("model", model)
            if (temperature != null) put("temperature", temperature)
        }
        val conn = (URL(endpoint).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"; connectTimeout = 8000; readTimeout = 20000; doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (apiKey.isNotBlank()) setRequestProperty("Authorization", "Bearer $apiKey")
        }
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            return JSONObject(text).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } finally {
            conn.disconnect()
        }
    }
}
