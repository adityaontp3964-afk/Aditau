package com.jarvis.assistant.accessibility

import android.app.admin.DeviceAdminReceiver

/** Device-admin receiver used only for the "force-lock" policy (lock screen on voice command). */
class AdminReceiver : DeviceAdminReceiver()
