package com.jarvis.assistant.command

import org.json.JSONObject

/** Result of validating the AI model's reply. */
sealed class Plan {
    data class Reply(val text: String) : Plan()
    data class Run(val cmd: Cmd) : Plan()
    data class Rejected(val reason: String) : Plan()
    /** The model answered in plain text (old behaviour): shown as a normal chat reply. */
    data class NotJson(val raw: String) : Plan()
}

/**
 * Allowlist validator for AI-generated action requests. The model can only pick from [SYSTEM_PROMPT]'s action types;
 * anything else is rejected, string lengths are capped, and the model can NEVER produce a confirmation (Yes/No):
 * WhatsApp sends always go through the local confirmation step. Pure Kotlin + org.json so it is unit-testable.
 */
object ActionPlanner {
    val SYSTEM_PROMPT: String = """
You are FRIDAY, a concise Hindi/Hinglish/English voice assistant that controls an Android phone.
Reply with exactly ONE JSON object and nothing else. Pick one of these types:
{"type":"CHAT","reply":"short answer in the user's language, max two sentences"}
{"type":"OPEN_APP","app":"youtube"}
{"type":"NAVIGATE","action":"BACK|HOME|RECENTS"}
{"type":"SCROLL","direction":"DOWN|UP"}
{"type":"REFRESH"}
{"type":"TYPE_TEXT","text":"text to type in the focused field"}
{"type":"CLEAR_TEXT"}
{"type":"SUBMIT_SEARCH"}
{"type":"WEB_SEARCH","query":"..."}
{"type":"YOUTUBE_SEARCH","query":"..."}
{"type":"VOLUME","direction":"UP|DOWN|MUTE"}
{"type":"TORCH","state":"ON|OFF"}
{"type":"OPEN_SETTINGS","screen":"WIFI|BLUETOOTH|DISPLAY|SOUND|ACCESSIBILITY"}
{"type":"WHATSAPP_OPEN"}
{"type":"WHATSAPP_OPEN_CHAT","recipient":"contact name"}
{"type":"WHATSAPP_SEND_MESSAGE","recipient":"contact name, or empty to use the chat selected earlier","message":"text","requires_confirmation":true}
Rules: use CHAT for conversation and general knowledge. Use an action type only when the user clearly asks for that phone action. Never invent other types. Never claim an action was done; the phone app executes it and reports the result. The app always asks the user to confirm before sending a WhatsApp message.
""".trimIndent()

    private const val MAX_TEXT = 1000

    fun parse(raw: String): Plan {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return Plan.NotJson(raw)
        val o = try { JSONObject(raw.substring(start, end + 1)) } catch (_: Exception) { return Plan.NotJson(raw) }

        fun str(key: String, max: Int): String {
            val v = o.optString(key, "").trim()
            return if (v.equals("null", ignoreCase = true)) "" else v.take(max)
        }
        fun reject(why: String) = Plan.Rejected(why)

        return when (str("type", 40).uppercase()) {
            "CHAT" -> str("reply", MAX_TEXT).let { if (it.isEmpty()) reject("empty reply") else Plan.Reply(it) }
            "OPEN_APP" -> str("app", 60).let { if (it.isEmpty()) reject("no app") else Plan.Run(Cmd.OpenApp(it.lowercase())) }
            "NAVIGATE" -> when (str("action", 20).uppercase()) {
                "BACK" -> Plan.Run(Cmd.Back)
                "HOME" -> Plan.Run(Cmd.Home)
                "RECENTS" -> Plan.Run(Cmd.Recents)
                else -> reject("bad navigate action")
            }
            "SCROLL" -> when (str("direction", 10).uppercase()) {
                "DOWN" -> Plan.Run(Cmd.Scroll(true))
                "UP" -> Plan.Run(Cmd.Scroll(false))
                else -> reject("bad scroll direction")
            }
            "REFRESH" -> Plan.Run(Cmd.Refresh)
            "TYPE_TEXT" -> str("text", MAX_TEXT).let { if (it.isEmpty()) reject("no text") else Plan.Run(Cmd.TypeText(it)) }
            "CLEAR_TEXT" -> Plan.Run(Cmd.ClearText)
            "SUBMIT_SEARCH" -> Plan.Run(Cmd.Submit)
            "WEB_SEARCH" -> str("query", 200).let { if (it.isEmpty()) reject("no query") else Plan.Run(Cmd.WebSearch(it)) }
            "YOUTUBE_SEARCH" -> str("query", 200).let { if (it.isEmpty()) reject("no query") else Plan.Run(Cmd.YouTubeSearch(it)) }
            "VOLUME" -> when (str("direction", 10).uppercase()) {
                "UP" -> Plan.Run(Cmd.Volume(1))
                "DOWN" -> Plan.Run(Cmd.Volume(-1))
                "MUTE" -> Plan.Run(Cmd.Volume(0))
                else -> reject("bad volume direction")
            }
            "TORCH" -> when (str("state", 10).uppercase()) {
                "ON" -> Plan.Run(Cmd.Torch(true))
                "OFF" -> Plan.Run(Cmd.Torch(false))
                else -> reject("bad torch state")
            }
            "OPEN_SETTINGS" -> when (str("screen", 20).uppercase()) {
                "WIFI" -> Plan.Run(Cmd.OpenSettings("wifi"))
                "BLUETOOTH" -> Plan.Run(Cmd.OpenSettings("bluetooth"))
                "DISPLAY" -> Plan.Run(Cmd.OpenSettings("display"))
                "SOUND" -> Plan.Run(Cmd.OpenSettings("sound"))
                "ACCESSIBILITY" -> Plan.Run(Cmd.OpenSettings("accessibility"))
                else -> reject("bad settings screen")
            }
            "WHATSAPP_OPEN" -> Plan.Run(Cmd.OpenApp("whatsapp"))
            "WHATSAPP_OPEN_CHAT" -> str("recipient", 60).let { if (it.isEmpty()) reject("no recipient") else Plan.Run(Cmd.WhatsAppOpenChat(it)) }
            "WHATSAPP_SEND_MESSAGE" -> {
                val message = str("message", MAX_TEXT)
                val recipient = str("recipient", 60)
                when {
                    message.isEmpty() -> reject("no message")
                    // requires_confirmation from the model is ignored on purpose: sending always asks the user first.
                    recipient.isEmpty() -> Plan.Run(Cmd.WhatsAppToContext(message))
                    else -> Plan.Run(Cmd.WhatsApp(recipient, message))
                }
            }
            else -> reject("unknown type")
        }
    }
}
