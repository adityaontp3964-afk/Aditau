package com.jarvis.assistant.command

import com.jarvis.assistant.data.DEFAULT_WAKE_PHRASE

/**
 * Text-based wake phrase matching on top of continuous Vosk recognition.
 * This is NOT a dedicated wake-word engine: it is ordinary speech recognition whose output is compared to the phrase.
 * Any phrase can be saved, but it is only detected if the Vosk model recognises its words (use the wake-word test).
 */
object WakeMatcher {
    /** Common mis-hearings of built-in names, keyed by the last word of the wake phrase. */
    private val aliasGroups = mapOf(
        "friday" to listOf("friday", "fry day", "fri day", "frieday", "fraiday", "freiday", "फ्राइडे", "फ्राईडे"),
        "jarvis" to listOf("jarvis", "jar vis", "jarvas", "jarvish", "jarves", "jarwis", "javis", "जार्विस", "जारविस")
    )

    /** Returns null if [phrase] is acceptable as a wake phrase, otherwise a short reason. */
    fun validate(phrase: String): String? {
        val p = phrase.trim()
        if (p.length < 3) return "Kam se kam 3 akshar chahiye"
        if (p.split(Regex("\\s+")).size > 4) return "Zyada se zyada 4 shabd"
        if (!p.all { it.isLetter() || it.isWhitespace() }) return "Sirf akshar aur space (koi number/symbol nahi)"
        return null
    }

    fun matches(text: String, phrase: String): Boolean {
        val t = text.lowercase().trim()
        if (t.isEmpty()) return false
        val p = phrase.lowercase().trim().ifEmpty { DEFAULT_WAKE_PHRASE }
        if (t.contains(p)) return true
        val key = p.split(" ").last()
        aliasGroups[key]?.let { group -> return group.any { t.contains(it) } }
        return key.length >= 4 && t.contains(key)
    }
}
