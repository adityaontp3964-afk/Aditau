package com.jarvis.assistant.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.command.PermissionManager
import com.jarvis.assistant.command.WakeMatcher
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.data.DEFAULT_WAKE_PHRASE
import com.jarvis.assistant.data.RecogMode
import com.jarvis.assistant.data.VoiceState
import com.jarvis.assistant.voice.OnlineRecognizer
import com.jarvis.assistant.voice.Tts
import com.jarvis.assistant.voice.TtsOptions
import com.jarvis.assistant.voice.VoiceOption
import com.jarvis.assistant.voice.VoiceService
import com.jarvis.assistant.voice.VoskEngine
import kotlinx.coroutines.delay
import java.util.Locale

/** Starts the first intent the device can handle; returns false if none could be started. */
private fun startFirst(ctx: Context, vararg intents: Intent): Boolean {
    for (i in intents) {
        try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true } catch (_: Exception) {}
    }
    return false
}

@Composable
fun RecognitionPanel() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as JarvisApp
    val prefs by app.settings.prefs.collectAsStateWithLifecycle()
    val engineUsed by AssistantState.recogEngine.collectAsStateWithLifecycle()
    val tick = rememberResumeTick()
    val onlineOk = remember(tick) { OnlineRecognizer.isAvailable(ctx) }
    val net = remember(tick) { OnlineRecognizer.hasInternet(ctx) }
    val hasModel = remember(tick, prefs.recogLang) { VoskEngine.hasModel(ctx, prefs.recogLang) }

    HudPanel("SPEECH RECOGNITION MODE") {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            HudChip("ONLINE", prefs.recogMode == RecogMode.ONLINE) { app.settings.update { it.copy(recogMode = RecogMode.ONLINE) } }
            HudChip("OFFLINE", prefs.recogMode == RecogMode.OFFLINE) { app.settings.update { it.copy(recogMode = RecogMode.OFFLINE) } }
            HudChip("AUTOMATIC", prefs.recogMode == RecogMode.AUTO) { app.settings.update { it.copy(recogMode = RecogMode.AUTO) } }
        }
        Spacer(Modifier.height(8.dp))
        HudText(
            when (prefs.recogMode) {
                RecogMode.ONLINE -> "Online: Android ki speech service (aam taur par Google) use hoti hai. Internet chahiye; awaaz us service ko jaati hai. Hindi, Hinglish aur English ke liye behtar hai. Free hai, par provider ki apni limits ho sakti hain."
                RecogMode.OFFLINE -> "Offline: Vosk se phone par hi recognition; internet nahi chahiye. Pehle neeche se voice model download karna zaroori hai. Accuracy online se kam ho sakti hai."
                RecogMode.AUTO -> "Automatic: internet ho to Online, warna ya online fail hone par Offline (agar model installed ho). Fail hone ke baad 1 minute tak seedha Offline chalta hai, baar-baar switch nahi hota."
            }, size = 11.sp, color = Hud.Sub
        )
        Spacer(Modifier.height(8.dp))
        StatusRow("ONLINE SERVICE", if (onlineOk) "AVAILABLE" else "NOT FOUND", onlineOk)
        StatusRow("INTERNET", if (net) "CONNECTED" else "NOT CONNECTED", net)
        StatusRow("OFFLINE MODEL (${prefs.recogLang.uppercase()})", if (hasModel) "INSTALLED" else "MISSING", hasModel)
        StatusRow("LAST ENGINE USED", engineUsed, null)
        if (prefs.recogMode == RecogMode.OFFLINE && !hasModel)
            HudText("Offline mode chuna hai par model installed nahi hai; voice commands tab tak nahi chalenge.", size = 11.sp, color = Hud.Bad)
        if (prefs.recogMode == RecogMode.ONLINE && !onlineOk)
            HudText("Is phone par online speech service nahi mili. Offline ya Automatic chuniye.", size = 11.sp, color = Hud.Bad)
    }
    HudPanel("COMMAND LANGUAGE") {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudChip("ENGLISH / HINGLISH", prefs.recogLang == "en") { app.settings.update { it.copy(recogLang = "en") } }
            HudChip("HINDI", prefs.recogLang == "hi") { app.settings.update { it.copy(recogLang = "hi") } }
        }
        Spacer(Modifier.height(6.dp))
        HudText("Ye bhasha Online (en-IN / hi-IN) aur Offline (Vosk model) dono ke liye use hoti hai. Hinglish ke liye English/Hinglish rakhiye; Hindi mode Devanagari output deta hai, jisse aam commands (YouTube, Wi-Fi, torch...) pehchaane jaate hain. Perfect accuracy ki guarantee nahi hai.",
            size = 11.sp, color = Hud.Sub)
    }
}

@Composable
fun SpeechOutputPanel() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as JarvisApp
    val prefs by app.settings.prefs.collectAsStateWithLifecycle()
    val err by AssistantState.error.collectAsStateWithLifecycle()
    val tick = rememberResumeTick()
    val tts = remember { Tts(ctx.applicationContext) }
    DisposableEffect(Unit) { onDispose { tts.shutdown() } }

    var ready by remember { mutableStateOf(false) }
    var voices by remember { mutableStateOf(emptyList<VoiceOption>()) }
    var hindiOk by remember { mutableStateOf<Boolean?>(null) }
    LaunchedEffect(tts, tick) {
        repeat(40) {
            if (tts.isReady) {
                ready = true
                voices = tts.voiceOptions()
                hindiOk = tts.hasLanguage(Locale("hi", "IN"))
                return@LaunchedEffect
            }
            delay(250)
        }
    }

    var rate by remember { mutableFloatStateOf(prefs.ttsRate) }
    var pitch by remember { mutableFloatStateOf(prefs.ttsPitch) }
    var menu by remember { mutableStateOf(false) }
    val currentLabel = when {
        prefs.ttsVoice.isBlank() -> "AUTOMATIC"
        else -> voices.firstOrNull { it.name == prefs.ttsVoice }?.label ?: prefs.ttsVoice
    }

    HudPanel("SPEECH OUTPUT (TEXT-TO-SPEECH)") {
        HudText("LANGUAGE", size = 10.sp, color = Hud.Sub)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudChip("ENGLISH (IN)", prefs.ttsLang == "en") { app.settings.update { it.copy(ttsLang = "en") } }
            HudChip("HINDI (IN)", prefs.ttsLang == "hi") { app.settings.update { it.copy(ttsLang = "hi") } }
        }
        Spacer(Modifier.height(8.dp))
        StatusRow("TTS ENGINE", if (ready) "READY" else "STARTING", if (ready) true else null)
        StatusRow("HINDI (hi-IN) VOICE DATA", when (hindiOk) { true -> "INSTALLED"; false -> "MISSING"; null -> "CHECKING" }, hindiOk)
        Spacer(Modifier.height(8.dp))
        HudText("VOICE", size = 10.sp, color = Hud.Sub)
        Box(Modifier.fillMaxWidth()) {
            HudButton(currentLabel, { menu = true }, Modifier.fillMaxWidth(), enabled = voices.isNotEmpty())
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(
                    text = { HudText("AUTOMATIC", size = 12.sp) },
                    onClick = { app.settings.update { it.copy(ttsVoice = "") }; menu = false }
                )
                voices.forEach { v ->
                    DropdownMenuItem(
                        text = { HudText(v.label, size = 12.sp) },
                        onClick = { app.settings.update { it.copy(ttsVoice = v.name) }; menu = false }
                    )
                }
            }
        }
        if (ready && voices.isEmpty())
            HudText("Engine ne koi voice list nahi di; automatic voice use hogi.", size = 11.sp, color = Hud.Warn)
        Spacer(Modifier.height(8.dp))
        HudText("SPEED  ${String.format(Locale.US, "%.1f", rate)}x", size = 10.sp, color = Hud.Sub)
        Slider(value = rate, onValueChange = { rate = it }, valueRange = 0.5f..2.0f,
            onValueChangeFinished = { app.settings.update { it.copy(ttsRate = rate) } })
        HudText("PITCH  ${String.format(Locale.US, "%.1f", pitch)}", size = 10.sp, color = Hud.Sub)
        Slider(value = pitch, onValueChange = { pitch = it }, valueRange = 0.5f..2.0f,
            onValueChangeFinished = { app.settings.update { it.copy(ttsPitch = pitch) } })
        Spacer(Modifier.height(4.dp))
        HudButton("TEST VOICE", {
            AssistantState.error.value = null
            tts.speak("Namaste, main FRIDAY hoon. Ye meri awaaz ka test hai.", prefs.ttsLang,
                TtsOptions(prefs.ttsVoice, rate, pitch)) {}
        }, Modifier.fillMaxWidth(), enabled = ready)
        err?.let { Spacer(Modifier.height(6.dp)); HudText(it, size = 11.sp, color = Hud.Warn) }
        Spacer(Modifier.height(8.dp))
        HudButton("INSTALL / MANAGE VOICE DATA", {
            startFirst(ctx,
                Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA),
                Intent("com.android.settings.TTS_SETTINGS"),
                Intent(Settings.ACTION_SETTINGS))
        }, Modifier.fillMaxWidth(), color = Hud.Blue)
        Spacer(Modifier.height(6.dp))
        HudText("Hindi voice: Phone Settings > Text-to-speech mein Hindi (India) voice data install kijiye, phir yahan HINDI (IN) chuniye. Android voice ka gender app ko nahi batata, isliye har voice chun kar TEST VOICE se suniye aur jo pasand aaye rakhiye. Replies Roman Hinglish mein hote hain; English (IN) voice unhe aksar behtar bolti hai. Local voice free hai aur kisi account ki zaroorat nahi.",
            size = 11.sp, color = Hud.Sub)
    }
}

@Composable
fun WakeWordPanel() {
    val ctx = LocalContext.current
    val app = ctx.applicationContext as JarvisApp
    val prefs by app.settings.prefs.collectAsStateWithLifecycle()
    val state by AssistantState.state.collectAsStateWithLifecycle()
    val testResult by AssistantState.wakeTest.collectAsStateWithLifecycle()
    var phrase by remember { mutableStateOf(prefs.wakePhrase) }
    val problem = WakeMatcher.validate(phrase)
    val listening = state == VoiceState.WAITING_FOR_WAKE_WORD
    val busy = state == VoiceState.INITIALIZING || state == VoiceState.LISTENING || state == VoiceState.PROCESSING ||
        state == VoiceState.SPEAKING || state == VoiceState.AWAITING_CONFIRMATION || listening

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) VoiceService.testWake(ctx) else AssistantState.wakeTest.value = "Test ke liye Microphone permission chahiye."
    }

    HudPanel("WAKE WORD") {
        Row(verticalAlignment = Alignment.CenterVertically) {
            HudText("ENABLE WAKE WORD", modifier = Modifier.weight(1f), size = 13.sp)
            Switch(prefs.wakeEnabled, { on ->
                app.settings.update { it.copy(wakeEnabled = on) }
                if (!on && AssistantState.state.value == VoiceState.WAITING_FOR_WAKE_WORD) VoiceService.stop(ctx)
            })
        }
        Spacer(Modifier.height(6.dp))
        StatusRow("DETECTION",
            when {
                !prefs.wakeEnabled -> "DISABLED"
                listening -> "ACTIVE (MIC LIVE)"
                else -> "NOT RUNNING"
            }, if (!prefs.wakeEnabled) null else listening)
        Spacer(Modifier.height(8.dp))
        HudField(phrase, {
            phrase = it
            if (WakeMatcher.validate(it) == null) app.settings.update { p -> p.copy(wakePhrase = it.trim().lowercase()) }
        }, "Wake phrase (default: $DEFAULT_WAKE_PHRASE)")
        problem?.let { HudText("Save nahi hua: $it", size = 11.sp, color = Hud.Bad) }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            HudButton("RESET PHRASE", {
                phrase = DEFAULT_WAKE_PHRASE
                app.settings.update { it.copy(wakePhrase = DEFAULT_WAKE_PHRASE) }
            }, Modifier.weight(1f), color = Hud.Blue)
            HudButton("TEST WAKE WORD", {
                AssistantState.wakeTest.value = null
                if (PermissionManager.mic(ctx)) VoiceService.testWake(ctx) else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }, Modifier.weight(1f), enabled = problem == null && !busy)
        }
        testResult?.let {
            Spacer(Modifier.height(6.dp))
            HudText(it, size = 12.sp, color = if (it.startsWith("DETECTED")) Hud.Good else Hud.Warn)
        }
        Spacer(Modifier.height(6.dp))
        HudText("Wake detection phone par hi hota hai (Vosk offline model); wake-word ke liye awaaz internet par nahi bheji jaati. Ye dedicated wake-word engine nahi hai: normal speech recognition ka text phrase se match hota hai, isliye koi bhi phrase save ho jaata hai par tabhi chalta hai jab model uske shabd pehchaane. TEST WAKE WORD se check kijiye. Wake word ke liye English voice model installed hona zaroori hai, aur mic hamesha live rehta hai (battery zyada lagti hai; kuch phones background mic rok dete hain). PUSH TO TALK button wake word ke bina hamesha chalta hai.",
            size = 11.sp, color = Hud.Sub)
    }
}

/** Last block of the Settings screen. */
@Composable
fun AboutCredits() {
    Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(Hud.Dim))
        Spacer(Modifier.height(16.dp))
        HudText("ABOUT", size = 11.sp, color = Hud.Sub, spacing = 2.sp)
        Spacer(Modifier.height(8.dp))
        HudText("Speech recognition uses Vosk (Apache License 2.0). Vosk models are downloaded separately from alphacephei.com and keep their own licences.",
            size = 11.sp, color = Hud.Sub, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        HudText("Whole credit goes to Aditya", size = 14.sp, color = Hud.Cyan, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        HudText("© 2026 Aditya. All rights reserved.", size = 12.sp, color = Hud.Txt, align = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp))
    }
}
