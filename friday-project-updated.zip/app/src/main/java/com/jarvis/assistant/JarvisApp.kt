package com.jarvis.assistant

import android.app.Application
import com.jarvis.assistant.data.HistoryRepository
import com.jarvis.assistant.data.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob

class JarvisApp : Application() {
    val settings by lazy { SettingsRepository(this) }
    val history by lazy { HistoryRepository(this) }
    /** App-level scope for work that must outlive a screen (model download, AI test). */
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
}
