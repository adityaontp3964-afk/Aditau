package com.jarvis.assistant.data

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/** How spoken commands are recognised. Wake-word detection is always local (Vosk) regardless of this mode. */
enum class RecogMode { ONLINE, OFFLINE, AUTO }

const val DEFAULT_WAKE_PHRASE = "hey friday"

data class Prefs(
    val userName: String = "",
    val wakePhrase: String = DEFAULT_WAKE_PHRASE,
    val wakeEnabled: Boolean = true,
    val recogMode: RecogMode = RecogMode.AUTO,
    val recogLang: String = "en",   // "en" or "hi" (Vosk model used for commands)
    val ttsLang: String = "en",     // "en" -> en-IN voice, "hi" -> hi-IN voice
    val ttsVoice: String = "",      // exact Android Voice name; "" = automatic
    val ttsRate: Float = 1.0f,      // 0.5 .. 2.0
    val ttsPitch: Float = 1.0f,     // 0.5 .. 2.0
    val greeting: String = "",
    val aiEnabled: Boolean = false,
    val aiEndpoint: String = "",    // full URL of an OpenAI-compatible /chat/completions endpoint
    val aiModel: String = ""
)

class SettingsRepository(context: Context) {
    private val sp = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)
    private val _prefs = MutableStateFlow(load())
    val prefs: StateFlow<Prefs> = _prefs

    private fun load() = Prefs(
        userName = sp.getString("userName", "") ?: "",
        // Settings saved by the JARVIS build still hold the old default phrase; move them to the FRIDAY default.
        wakePhrase = (sp.getString("wakePhrase", DEFAULT_WAKE_PHRASE) ?: DEFAULT_WAKE_PHRASE)
            .let { if (it.isBlank() || it == "hey jarvis") DEFAULT_WAKE_PHRASE else it },
        wakeEnabled = sp.getBoolean("wakeEnabled", true),
        recogMode = runCatching { RecogMode.valueOf(sp.getString("recogMode", RecogMode.AUTO.name) ?: "AUTO") }
            .getOrDefault(RecogMode.AUTO),
        recogLang = sp.getString("recogLang", "en") ?: "en",
        ttsLang = sp.getString("ttsLang", "en") ?: "en",
        ttsVoice = sp.getString("ttsVoice", "") ?: "",
        ttsRate = sp.getFloat("ttsRate", 1.0f).coerceIn(0.5f, 2.0f),
        ttsPitch = sp.getFloat("ttsPitch", 1.0f).coerceIn(0.5f, 2.0f),
        greeting = sp.getString("greeting", "") ?: "",
        aiEnabled = sp.getBoolean("aiEnabled", false),
        aiEndpoint = sp.getString("aiEndpoint", "") ?: "",
        aiModel = sp.getString("aiModel", "") ?: ""
    )

    fun update(transform: (Prefs) -> Prefs) {
        val n = transform(_prefs.value)
        _prefs.value = n
        sp.edit()
            .putString("userName", n.userName)
            .putString("wakePhrase", n.wakePhrase)
            .putBoolean("wakeEnabled", n.wakeEnabled)
            .putString("recogMode", n.recogMode.name)
            .putString("recogLang", n.recogLang)
            .putString("ttsLang", n.ttsLang)
            .putString("ttsVoice", n.ttsVoice)
            .putFloat("ttsRate", n.ttsRate)
            .putFloat("ttsPitch", n.ttsPitch)
            .putString("greeting", n.greeting)
            .putBoolean("aiEnabled", n.aiEnabled)
            .putString("aiEndpoint", n.aiEndpoint)
            .putString("aiModel", n.aiModel)
            .apply()
    }

    fun saveApiKey(key: String) {
        sp.edit().putString("aiKey", if (key.isBlank()) "" else SecretStore.encrypt(key.trim())).apply()
    }

    fun apiKey(): String =
        sp.getString("aiKey", "")?.takeIf { it.isNotEmpty() }?.let { SecretStore.decrypt(it) } ?: ""

    fun hasApiKey(): Boolean = !sp.getString("aiKey", "").isNullOrEmpty()

    fun reset() {
        sp.edit().clear().apply()
        _prefs.value = Prefs()
    }
}
