package com.jarvis.assistant.command

import android.accessibilityservice.AccessibilityService
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import com.jarvis.assistant.JarvisApp
import com.jarvis.assistant.accessibility.JarvisAccessibilityService
import com.jarvis.assistant.accessibility.TypeOutcome
import com.jarvis.assistant.ai.AiClient
import com.jarvis.assistant.data.AssistantState
import com.jarvis.assistant.data.Prefs
import com.jarvis.assistant.voice.OnlineRecognizer
import org.json.JSONObject
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Maps parsed intents to real Android actions. Never reports success for an action that did not run. */
class CommandDispatcher(private val ctx: Context, private val app: JarvisApp) {
    val confirmation = ConfirmationManager()
    private val whatsapp = WhatsAppController(ctx)
    @Volatile private var awaiting: Awaiting? = null

    /** True while the assistant needs the user's next utterance as an answer (yes/no, a name, a message, text to type). */
    val expectsFollowUp: Boolean get() = confirmation.hasPending || awaiting != null

    /** Forgets any pending confirmation or question (silence, session end). */
    fun cancelPending() { confirmation.clear(); awaiting = null }

    private val knownPackages = mapOf(
        "youtube" to "com.google.android.youtube", "whatsapp" to "com.whatsapp", "instagram" to "com.instagram.android",
        "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm", "maps" to "com.google.android.apps.maps",
        "telegram" to "org.telegram.messenger", "spotify" to "com.spotify.music", "facebook" to "com.facebook.katana"
    )

    suspend fun dispatch(cmd: Cmd, turns: List<Pair<String, String>>, raw: String = ""): CommandResult {
        val p = app.settings.prefs.value
        val who = p.userName.ifBlank { "boss" }
        awaiting?.let { aw ->
            val answered = handleAwaiting(aw, cmd, raw, who)
            if (answered != null) return answered
            // not an answer: the user gave a different, real command, so run it normally
        }
        if (cmd !is Cmd.Yes && cmd !is Cmd.No) confirmation.clear()
        return execute(cmd, turns, p, who)
    }

    private suspend fun execute(cmd: Cmd, turns: List<Pair<String, String>>, p: Prefs, who: String): CommandResult {
        return when (cmd) {
            is Cmd.Yes -> confirmation.take()?.invoke()
                ?: CommandResult(false, "Kis baat ke liye haan, $who? Pehle koi command boliye.")
            is Cmd.No -> { confirmation.clear(); CommandResult(true, "Theek hai $who, cancel kar diya.") }
            is Cmd.Greeting -> CommandResult(true, "Haan $who, boliye. Main sun raha hoon.")
            is Cmd.Thanks -> CommandResult(true, "Koi baat nahi $who.")
            is Cmd.HowAreYou -> CommandResult(true, "Main theek hoon $who. Aap bataiye, kya karun?")
            is Cmd.AskName -> CommandResult(true, "Mera naam FRIDAY hai.")
            is Cmd.AskUserName ->
                if (p.userName.isBlank()) CommandResult(true, "Aapne abhi apna naam nahi bataya. Profile mein naam daal dijiye.")
                else CommandResult(true, "Aapka naam ${p.userName} hai.")
            is Cmd.TellTime -> CommandResult(true, "Abhi samay ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date())} hai.")
            is Cmd.TellDate -> CommandResult(true, "Aaj ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date())} hai.")
            is Cmd.Stop -> CommandResult(true, "Theek hai $who, main band ho raha hoon.", stopSession = true)
            is Cmd.OpenApp -> openApp(cmd.name, who)
            is Cmd.WebSearch -> launchUri("https://www.google.com/search?q=${Uri.encode(cmd.query)}", null,
                "Bilkul $who, '${cmd.query}' search kar raha hoon.", who)
            is Cmd.YouTubeSearch -> launchUri("https://www.youtube.com/results?search_query=${Uri.encode(cmd.query)}",
                "com.google.android.youtube", "Bilkul $who, YouTube par '${cmd.query}' dhundh raha hoon.", who)
            is Cmd.OpenSettings -> openSettings(cmd.kind, who)
            is Cmd.Swipe -> withAccessibility(who) { it.swipe(cmd.up) }
                .let { if (it.success) CommandResult(true, if (cmd.up) "Agla video." else "Pichla video.") else it }
            is Cmd.Back -> withAccessibility(who) { it.global(AccessibilityService.GLOBAL_ACTION_BACK) }
                .let { if (it.success) CommandResult(true, "Peeche aa gaya.") else it }
            is Cmd.Home -> withAccessibility(who) { it.global(AccessibilityService.GLOBAL_ACTION_HOME) }
                .let { if (it.success) CommandResult(true, "Home screen par aa gaya.") else it }
            is Cmd.Recents -> withAccessibility(who) { it.global(AccessibilityService.GLOBAL_ACTION_RECENTS) }
                .let { if (it.success) CommandResult(true, "Recent apps khol diye $who.") else it }
            is Cmd.Scroll -> scroll(cmd.down, who)
            is Cmd.Refresh -> refresh(who)
            is Cmd.TypeText -> typeText(cmd.text, who)
            is Cmd.ClearText -> clearText(who)
            is Cmd.Submit -> submit(who)
            is Cmd.Dictate -> {
                confirmation.clear()
                awaiting = Awaiting.TypeText
                CommandResult(true, "$who, kya type karun?", status = ActionStatus.ACTION_STARTED)
            }
            is Cmd.Volume -> changeVolume(cmd.direction, who)
            is Cmd.Torch -> setTorch(cmd.on, who)
            is Cmd.Lock -> lockPhone(who)
            is Cmd.WhatsApp -> sendToContact(cmd.recipient, cmd.text, who)
            is Cmd.WhatsAppOpenChat -> openChat(cmd.name, who, null)
            is Cmd.WhatsAppToContext -> sendToContext(cmd.text, who)
            is Cmd.MissingArg -> CommandResult(false, cmd.question, followUp = cmd.question)
            is Cmd.Chat -> chat(cmd.text, turns, p, who)
            is Cmd.Unknown -> CommandResult(false, "Samajh nahi aaya $who. Aap 'YouTube khol' ya 'samay kya hua' jaisa bol sakte hain.",
                status = ActionStatus.UNSUPPORTED_ACTION)
        }
    }

    // ---- follow-up answers (names, message text, dictation) ----

    private fun isCancel(cmd: Cmd) = cmd is Cmd.No

    /** Returns a result if [raw] was consumed as the answer, or null if the user issued some other real command instead. */
    private suspend fun handleAwaiting(aw: Awaiting, cmd: Cmd, raw: String, who: String): CommandResult? {
        if (cmd is Cmd.Stop) { awaiting = null; return null }
        if (isCancel(cmd)) { awaiting = null; return CommandResult(true, "Theek hai $who, cancel kar diya.") }
        val answer = raw.trim()
        return when (aw) {
            is Awaiting.TypeText -> { awaiting = null; typeText(answer, who) }
            is Awaiting.SearchQuery -> {
                awaiting = null
                if (answer.isEmpty()) CommandResult(false, "Kya search karna hai $who?")
                else launchUri("https://www.google.com/search?q=${Uri.encode(answer)}", null, "Bilkul $who, '$answer' search kar raha hoon.", who)
            }
            is Awaiting.MessageText -> {
                awaiting = null
                if (cmd is Cmd.WhatsAppToContext || cmd is Cmd.WhatsApp || cmd is Cmd.WhatsAppOpenChat) null   // a new WhatsApp command, not the message text
                else if (answer.isEmpty()) CommandResult(false, "Message khaali tha $who. Dobara bolke bhejna ho to 'usko message bhejo' boliye.")
                else askConfirmSend(aw.contact ?: AssistantContext.contact() ?: "", answer, who)
            }
            is Awaiting.ContactChoice -> {
                val pick = resolveChoice(aw.candidates, answer)
                if (pick != null) { awaiting = null; openChat(pick, who, aw.message) }
                else if (cmd !is Cmd.Chat && cmd !is Cmd.Unknown) { awaiting = null; null }
                else CommandResult(false, "Samajh nahi aaya $who. Inme se ek chuniye: ${aw.candidates.take(4).joinToString(", ")}.",
                    followUp = "choose", status = ActionStatus.AMBIGUOUS_CONTACT)
            }
        }
    }

    private fun resolveChoice(candidates: List<String>, answer: String): String? {
        val n = Normalizer.normalize(answer)
        val ordinals = mapOf("pehla" to 0, "pehle" to 0, "first" to 0, "1" to 0, "one" to 0,
            "doosra" to 1, "dusra" to 1, "second" to 1, "2" to 1, "two" to 1,
            "teesra" to 2, "tisra" to 2, "third" to 2, "3" to 2, "three" to 2)
        for (w in n.split(" ")) ordinals[w]?.let { if (it < candidates.size) return candidates[it] }
        val tokens = n.split(" ").filter { it.isNotEmpty() }
        if (tokens.isEmpty()) return null
        val hits = candidates.filter { c -> tokens.all { c.lowercase().contains(it) } }
        return if (hits.size == 1) hits[0] else null
    }

    // ---- launching ----

    /** Android 10+ blocks activity starts from the background unless the app may draw over other apps. */
    private fun canLaunch() = AssistantState.appForeground || Settings.canDrawOverlays(ctx)

    private fun backgroundBlocked(who: String) = CommandResult(false,
        "$who, background se app kholne ke liye 'Display over other apps' permission chahiye. Settings mein dijiye.")

    private fun start(i: Intent): Boolean = try {
        ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    private fun launchUri(url: String, pkg: String?, okMsg: String, who: String): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        val i = Intent(Intent.ACTION_VIEW, Uri.parse(url))
        if (pkg != null) {
            i.setPackage(pkg)
            if (start(i)) return CommandResult(true, okMsg)
            i.setPackage(null)
        }
        return if (start(i)) CommandResult(true, okMsg) else CommandResult(false, "Ye kholne ke liye koi app nahi mili.")
    }

    private fun openApp(name: String, who: String): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        val key = closestKnown(name.lowercase().trim())
        if (key == "settings" || key == "setting") {
            return if (start(Intent(Settings.ACTION_SETTINGS))) CommandResult(true, "Bilkul $who, Settings khol raha hoon.")
            else CommandResult(false, "Settings nahi khul paayi.")
        }
        val special: Intent? = when (key) {
            "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "gallery", "photos", "photo" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY)
            "calculator" -> Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)
            "phone", "dialer" -> Intent(Intent.ACTION_DIAL)
            else -> null
        }
        if (special != null && start(special)) return CommandResult(true, "Bilkul $who, $key khol raha hoon.")
        val pm = ctx.packageManager
        val pkg: String? = knownPackages[key]?.takeIf { pm.getLaunchIntentForPackage(it) != null } ?: run {
            val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(main, 0).map { it.loadLabel(pm).toString() to it.activityInfo.packageName }
            val exact = apps.filter { it.first.equals(name, true) }.distinctBy { it.second }
            val cand = if (exact.isNotEmpty()) exact else apps.filter { it.first.contains(name, true) }.distinctBy { it.second }
            when {
                cand.size == 1 -> cand[0].second
                cand.size > 1 -> return CommandResult(false,
                    "Kaun sa kholun $who: ${cand.take(3).joinToString(", ") { it.first }}? Poora naam boliye.")
                else -> null
            }
        }
        if (pkg == null) return CommandResult(false, "$who, '$name' naam ki app mujhe is phone mein nahi mili.")
        val li = pm.getLaunchIntentForPackage(pkg) ?: return CommandResult(false, "'$name' abhi nahi khul sakti.")
        return if (start(li)) CommandResult(true, "Bilkul $who, $name khol raha hoon.")
        else CommandResult(false, "'$name' kholne mein dikkat aayi.")
    }

    /** Fixes small misrecognitions ("youtub", "instagam") by matching to a known app name within edit distance 2. */
    private fun closestKnown(name: String): String {
        if (name in knownPackages || name.length < 4) return name
        val best = knownPackages.keys.minByOrNull { editDistance(it, name) } ?: return name
        return if (editDistance(best, name) <= 2) best else name
    }

    private fun editDistance(a: String, b: String): Int {
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) for (j in 1..b.length)
            d[i][j] = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
        return d[a.length][b.length]
    }

    private fun openSettings(kind: String, who: String): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        val (action, label) = when (kind) {
            "wifi" -> Settings.ACTION_WIFI_SETTINGS to "Wi-Fi"
            "bluetooth" -> Settings.ACTION_BLUETOOTH_SETTINGS to "Bluetooth"
            "display" -> Settings.ACTION_DISPLAY_SETTINGS to "Display"
            "sound" -> Settings.ACTION_SOUND_SETTINGS to "Sound"
            else -> Settings.ACTION_ACCESSIBILITY_SETTINGS to "Accessibility"
        }
        return if (start(Intent(action)))
            CommandResult(true, "$label settings khol raha hoon $who. Android seedha on/off karne nahi deta, wahan se aap kar sakte hain.")
        else CommandResult(false, "$label settings nahi khul paayi.")
    }

    // ---- volume / torch ----

    private fun changeVolume(direction: Int, who: String): CommandResult = try {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
        val adj = when {
            direction > 0 -> android.media.AudioManager.ADJUST_RAISE
            direction < 0 -> android.media.AudioManager.ADJUST_LOWER
            else -> android.media.AudioManager.ADJUST_MUTE
        }
        am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, adj, android.media.AudioManager.FLAG_SHOW_UI)
        CommandResult(true, when {
            direction > 0 -> "Volume badha diya $who."
            direction < 0 -> "Volume kam kar diya $who."
            else -> "Volume mute kar diya $who."
        })
    } catch (e: Exception) { CommandResult(false, "Volume change nahi ho paaya: ${e.message}") }

    private fun setTorch(on: Boolean, who: String): CommandResult = try {
        val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
        val id = cm.cameraIdList.firstOrNull {
            cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
        if (id == null) CommandResult(false, "Is phone mein torch nahi mili.")
        else {
            cm.setTorchMode(id, on)
            CommandResult(true, if (on) "Torch on kar di $who." else "Torch off kar di $who.")
        }
    } catch (e: Exception) { CommandResult(false, "Torch control nahi ho paaya: ${e.message}") }

    // ---- accessibility-backed actions ----

    private fun withAccessibility(who: String, block: (JarvisAccessibilityService) -> Boolean): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return needsAccessibility(who)
        return if (block(s)) CommandResult(true, "Ho gaya.") else CommandResult(false, "Action complete nahi ho paya. Dobara try karo.")
    }

    private fun needsAccessibility(who: String) = CommandResult(false,
        "$who, Accessibility permission enabled nahi hai. Settings mein FRIDAY ko chalu kijiye.",
        status = ActionStatus.NEEDS_PERMISSION)

    private fun scroll(down: Boolean, who: String): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return needsAccessibility(who)
        val dir = if (down) "neeche" else "upar"
        if (s.scrollScreen(down)) return CommandResult(true, "Screen $dir scroll kar di $who.")
        return if (s.swipe(down)) CommandResult(true, "Scroll gesture bheja $who (is screen par scroll list nahi mili).", status = ActionStatus.ACTION_STARTED)
        else CommandResult(false, "Scroll nahi ho paaya. Dobara try karo.")
    }

    private fun refresh(who: String): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return needsAccessibility(who)
        return if (s.swipe(false))
            CommandResult(true, "Refresh ke liye neeche kheencha $who. Page refresh hua ya nahi, main verify nahi kar sakta.", status = ActionStatus.ACTION_STARTED)
        else CommandResult(false, "Refresh gesture nahi ho paaya. Dobara try karo.")
    }

    private fun typeText(text: String, who: String): CommandResult {
        if (text.isBlank()) return CommandResult(false, "Kya type karun $who?")
        val s = JarvisAccessibilityService.instance ?: return needsAccessibility(who)
        return when (s.typeText(text, append = true)) {
            TypeOutcome.OK -> CommandResult(true, "Text likh diya $who.")
            TypeOutcome.NO_FIELD -> CommandResult(false, "Screen par koi text box nahi mila $who. Pehle text box par tap kijiye.", status = ActionStatus.TARGET_NOT_FOUND)
            TypeOutcome.PASSWORD -> CommandResult(false, "Password field mein main type nahi karta $who.", status = ActionStatus.UNSUPPORTED_ACTION)
            TypeOutcome.FAILED -> CommandResult(false, "Text likhna complete nahi ho paya. Dobara try karo.")
        }
    }

    private fun clearText(who: String): CommandResult {
        val s = JarvisAccessibilityService.instance ?: return needsAccessibility(who)
        return when (s.clearText()) {
            TypeOutcome.OK -> CommandResult(true, "Text clear kar diya $who.")
            TypeOutcome.NO_FIELD -> CommandResult(false, "Screen par koi text box nahi mila $who.", status = ActionStatus.TARGET_NOT_FOUND)
            else -> CommandResult(false, "Text clear nahi ho paya. Is app mein ye supported nahi ho sakta.")
        }
    }

    private fun submit(who: String): CommandResult {
        val s = JarvisAccessibilityService.instance
        if (s != null && s.submitSearch()) return CommandResult(true, "Search dabaya $who.", status = ActionStatus.ACTION_STARTED)
        // nothing to submit on screen: behave like the old "search karo" and ask what to search for
        confirmation.clear()
        awaiting = Awaiting.SearchQuery
        return CommandResult(false, "Kya search karna hai $who?", followUp = "search")
    }

    private fun lockPhone(who: String): CommandResult {
        if (PermissionManager.adminActive(ctx)) {
            return try {
                (ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).lockNow()
                CommandResult(true, "Phone lock kar diya $who.")
            } catch (e: Exception) { CommandResult(false, "Lock nahi ho paaya: ${e.message}") }
        }
        val s = JarvisAccessibilityService.instance
        if (s != null && s.lockScreen()) return CommandResult(true, "Phone lock kar diya $who.")
        return CommandResult(false, "$who, lock ke liye Device Admin chalu karna hoga (Settings > Device Admin).")
    }

    // ---- WhatsApp ----

    private fun lookupContact(name: String): List<Pair<String, String>> {
        val out = LinkedHashMap<String, String>()
        ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
            "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { c ->
            while (c.moveToNext()) out.putIfAbsent(c.getString(0), c.getString(1))
        }
        return out.toList()
    }

    /** With Accessibility on, WhatsApp is driven through its real UI; otherwise the Contacts + wa.me fallback below is used. */
    private suspend fun sendToContact(recipient: String, text: String, who: String): CommandResult {
        if (JarvisAccessibilityService.instance != null) return openChat(recipient, who, text)
        return prepareWhatsApp(recipient, text, who)
    }

    private fun sendToContext(text: String?, who: String): CommandResult {
        val contact = AssistantContext.contact() ?: return CommandResult(false,
            "$who, kisko message bhejna hai? Pehle chat kholiye ('Kartavya ki chat kholo') ya naam batayiye.",
            status = ActionStatus.TARGET_NOT_FOUND)
        if (text.isNullOrBlank()) {
            confirmation.clear()
            awaiting = Awaiting.MessageText(contact)
            return CommandResult(true, "$who, $contact ko kya message bhejna hai?", status = ActionStatus.ACTION_STARTED)
        }
        return askConfirmSend(contact, text, who)
    }

    /** Opens [name]'s chat in WhatsApp (verified on screen). If [thenMessage] is set, asks for send confirmation next. */
    private suspend fun openChat(name: String, who: String, thenMessage: String?): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        return reportOpen(whatsapp.openChat(name), name, who, thenMessage)
    }

    private fun reportOpen(r: WhatsAppController.OpenResult, name: String, who: String, thenMessage: String?): CommandResult =
        when (r) {
            is WhatsAppController.OpenResult.Opened -> {
                AssistantContext.setContact(r.name)
                if (thenMessage != null) askConfirmSend(r.name, thenMessage, who)
                else CommandResult(true, "${r.name} ki chat khul gayi $who.")
            }
            is WhatsAppController.OpenResult.Ambiguous -> {
                confirmation.clear()
                awaiting = Awaiting.ContactChoice(r.candidates, thenMessage)
                CommandResult(false, "Kaun sa $name $who: ${r.candidates.take(4).joinToString(", ")}? Poora naam boliye.",
                    followUp = "choose", status = ActionStatus.AMBIGUOUS_CONTACT)
            }
            WhatsAppController.OpenResult.NotFound ->
                CommandResult(false, "Contact nahi mila. Naam dobara batao.", status = ActionStatus.TARGET_NOT_FOUND)
            WhatsAppController.OpenResult.NotInstalled ->
                CommandResult(false, "WhatsApp is phone mein installed nahi hai $who.")
            WhatsAppController.OpenResult.NeedsAccessibility -> needsAccessibility(who)
            is WhatsAppController.OpenResult.Failed ->
                CommandResult(false, "Action complete nahi ho paya: ${r.why}. Dobara try karo.")
        }

    private fun askConfirmSend(contact: String, message: String, who: String): CommandResult {
        if (contact.isBlank()) return CommandResult(false, "$who, kisko message bhejna hai? Naam batayiye.",
            status = ActionStatus.TARGET_NOT_FOUND)
        awaiting = null
        confirmation.set { sendConfirmed(contact, message, who) }
        return CommandResult(true, "$who, $contact ko '$message' message bhejna hai. Confirm karun?",
            requiresConfirmation = true, status = ActionStatus.NEEDS_CONFIRMATION)
    }

    /** Runs only after the user said yes. Reports success only if the screen shows the message was sent. */
    private suspend fun sendConfirmed(contact: String, message: String, who: String): CommandResult {
        if (!canLaunch()) return backgroundBlocked(who)
        return when (val r = whatsapp.sendMessage(contact, message)) {
            WhatsAppController.SendResult.Sent -> {
                AssistantContext.setContact(contact)
                CommandResult(true, "Message bhej diya $who. $contact ki chat mein dikh raha hai. Delivery main verify nahi kar sakta.")
            }
            WhatsAppController.SendResult.Unverified -> CommandResult(true,
                "Send dabaya aur text box khaali ho gaya $who, par message screen par dikha nahi. Chat ek baar check kar lijiye.",
                status = ActionStatus.ACTION_STARTED)
            is WhatsAppController.SendResult.Failed -> CommandResult(false, "Message send nahi ho paya: ${r.why}.")
            is WhatsAppController.SendResult.NeedsOpen -> reportOpen(r.result, contact, who, message)
        }
    }

    private fun prepareWhatsApp(recipient: String, text: String, who: String): CommandResult {
        if (!PermissionManager.contacts(ctx))
            return CommandResult(false, "$who, contact dhundhne ke liye Contacts permission chahiye. Settings mein dijiye.")
        val matches = lookupContact(recipient)
        if (matches.isEmpty()) return CommandResult(false, "'$recipient' naam ka contact nahi mila.")
        val exact = matches.filter { it.first.equals(recipient, true) }
        val chosen = when {
            exact.size == 1 -> exact[0]
            matches.size == 1 -> matches[0]
            else -> return CommandResult(false,
                "Kaun sa $recipient $who: ${matches.take(3).joinToString(", ") { it.first }}? Poora naam boliye.")
        }
        var digits = chosen.second.filter { it.isDigit() || it == '+' }.removePrefix("+")
        if (digits.length == 10) digits = "91$digits"   // assumes India (+91) for bare 10-digit numbers
        val msg = "$who, main ${chosen.first} ko WhatsApp par ye message bhejne wala hoon: $text. Bhej doon?"
        confirmation.set {
            if (!canLaunch()) return@set backgroundBlocked(who)
            val uri = Uri.parse("https://wa.me/$digits?text=${Uri.encode(text)}")
            val pkgs = listOf("com.whatsapp", "com.whatsapp.w4b")
            val opened = pkgs.any { start(Intent(Intent.ACTION_VIEW, uri).setPackage(it)) }
            if (!opened) return@set CommandResult(false, "WhatsApp nahi khul paaya. Kya WhatsApp install hai?")
            val svc = { JarvisAccessibilityService.instance }
            if (svc() == null) CommandResult(true,
                "Message WhatsApp mein tayyar hai $who, par Accessibility service band hai, isliye Send aap khud dabaiye.")
            else {
                var clicked = false
                repeat(12) { if (!clicked) { delay(500); clicked = svc()?.clickWhatsAppSend() == true } }
                if (clicked) CommandResult(true, "Send button dabaya $who. Delivery main verify nahi kar sakta.")
                else CommandResult(true, "Message tayyar hai par Send button nahi mila $who. Aap khud Send dabaiye.")
            }
        }
        return CommandResult(true, msg, requiresConfirmation = true)
    }

    // ---- AI ----

    private fun aiContext(): String = JSONObject()
        .put("last_chat_contact", AssistantContext.contact() ?: "")
        .put("accessibility_connected", JarvisAccessibilityService.instance != null)
        .toString()

    /** Unknown local command: ask the existing AI provider (same endpoint/key/model), which may answer or request an allowlisted action. */
    private suspend fun chat(text: String, turns: List<Pair<String, String>>, p: Prefs, who: String): CommandResult {
        if (!p.aiEnabled || p.aiEndpoint.isBlank())
            return CommandResult(false, "Ye mujhe samajh nahi aaya $who. AI configure nahi hai, isliye main sirf local commands kar sakta hoon.")
        val r = AiClient.plan(p.aiEndpoint, app.settings.apiKey(), p.aiModel, p.userName, turns, text, aiContext())
        return r.fold(
            onSuccess = { raw -> AssistantState.aiStatus.value = "ONLINE"; planToResult(raw, turns, p, who) },
            onFailure = {
                AssistantState.aiStatus.value = "ERROR"
                if (!OnlineRecognizer.hasInternet(ctx))
                    CommandResult(false, "Internet nahi hai $who, isliye AI abhi use nahi ho sakta. Local commands chalte rahenge.")
                else CommandResult(false, "AI se connect nahi ho paaya: ${it.message}")
            }
        )
    }

    private suspend fun planToResult(raw: String, turns: List<Pair<String, String>>, p: Prefs, who: String): CommandResult =
        when (val plan = ActionPlanner.parse(raw)) {
            is Plan.Reply -> CommandResult(true, plan.text, source = "AI")
            is Plan.NotJson ->
                if (plan.raw.isBlank()) CommandResult(false, "AI se khaali jawab aaya $who.", source = "AI")
                else CommandResult(true, plan.raw.trim(), source = "AI")
            is Plan.Rejected -> CommandResult(false, "Ye action abhi supported nahi hai $who.",
                status = ActionStatus.UNSUPPORTED_ACTION, source = "AI")
            is Plan.Run -> execute(plan.cmd, turns, p, who).copy(source = "AI")
        }
}
