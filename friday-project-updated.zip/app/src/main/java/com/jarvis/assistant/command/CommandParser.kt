package com.jarvis.assistant.command

/** Pure-Kotlin parser (no Android dependencies) so it can be unit-tested on the JVM. */
object CommandParser {
    private val YES = setOf("haan", "han", "ha", "yes", "yeah", "ok", "okay", "confirm", "bhej do", "bhejo", "kar do",
        "send", "sure", "theek hai", "bilkul", "send it", "yes send")
    private val NO = setOf("nahi", "nahin", "no", "cancel", "mat bhej", "mat bhejo", "mat karo", "ruko", "nope")

    private val R_WA_HINDI = Regex("^(\\S+) ko (?:whatsapp (?:par|pe|per|me|mein) )?(?:whatsapp|message|msg|sandesh) (?:(?:bhej\\w*|send|kar\\w*) )?(.+)$")
    private val R_WA_EN = Regex("^(?:send )?(?:a )?(?:whatsapp )?(?:message|msg|sandesh) (?:to )?(\\S+) (?:saying |that |ki )?(.+)$")
    // pronoun follow-ups: "usko hi message bhejo", "usko message bhejo hi", "usko ek message bhejna hai"
    private val R_PRON = Regex("^(?:usko|use|usse|unko|unhe|isko|ise|us ko) (.+)$")
    private val R_PRON_NOTEXT = Regex("^(?:whatsapp (?:par|pe|per|me|mein) )?(?:ek )?(?:message|msg|sandesh)(?: (?:bhej\\w*|send|karna|karo|do|de|hai|chahiye))*$")
    private val R_PRON_AFTER = Regex("^(?:whatsapp (?:par|pe|per|me|mein) )?(?:message|msg|sandesh) (?:bhej\\w*|send|kar\\w*|do|de) (.+)$")
    private val R_PRON_BEFORE = Regex("^(?:whatsapp (?:par|pe|per|me|mein) )?(?:ek )?(.+?) (?:message|msg|sandesh)(?: (?:bhej\\w*|send|kar\\w*|do|de))*$")
    // "kartavya ko hi message bhejo"
    private val R_WA_NAME_TEXT_MSG = Regex("^(.+?) ko (?:whatsapp (?:par|pe|per|me|mein) )?(.+?) (?:message|msg|sandesh) (?:bhej\\w*|send|kar\\w*|do|de)(?: .*)?$")
    // "kartavya ki chat kholo", "whatsapp mein kartavya ki chat open karo"
    private val R_WA_CHAT = Regex("^(?:whatsapp (?:mein|me|par|pe|per|main) )?(.+?) (?:ki|ka|ke) chat (?:khol\\w*|open|start|dikhao)(?: (?:kar|karo|do|de))*$")
    // typing
    private val R_DICTATE = Regex("^(?:jo(?: text| kuch| bhi)? (?:main|mai) bol\\w*(?: (?:wo|woh|vo|use|usse))? (?:type|likho|likh)\\w*|(?:type|likho|likh|typing))(?: (?:karo|kar|do|de|shuru karo))*$")
    private val R_TYPE_A = Regex("^(?:(?:search box|search bar|searchbox|text box|textbox|box|field|search) (?:mein|me|main|par|pe) )?(.+?) (?:likho|likh do|likh de|likh|type karo|type kar do|type kar)$")
    private val R_TYPE_B = Regex("^(?:likho|likh|type karo|type kar) (.+)$")
    private val R_TYPE_C = Regex("^type (?!of |a |an |the )(.+)$")
    private val SUBMIT_PHRASES = setOf("search karo", "search kar", "search kar do", "search button dabao", "enter dabao",
        "enter karo", "enter press karo", "submit", "submit karo")

    private val R_VERB_ONLY = Regex("^(bhej\\w*|send|kar\\w*)$")

    private val Y1 = Regex("^(?:search|play|dhundh\\w*|dhoondh\\w*|chala\\w*|laga\\w*) (?:for )?(.+?) (?:on |par |pe |per |me |mein )?youtube(?: .*)?$")
    private val Y3 = Regex("^(.+?) youtube (?:par|pe|per|me|mein|on) (?:search|play|chala\\w*|laga\\w*|dhundh\\w*).*$")
    private val Y2 = Regex("^youtube (?:par |pe |per |me |mein |on )?(?:search |play |dhundh\\w* )?(.+?)(?: (?:search|play|chala\\w*|laga\\w*|dhundh\\w*))?(?: (?:kar|karo|do|de))*$")

    private val S1 = Regex("^(?:search|google|dhundh\\w*|dhoondh\\w*)(?: for)? (.+?)(?: (?:kar|karo|do|de))*$")
    private val S2 = Regex("^(.+?) (?:search|google)(?: (?:kar|karo|do))*$")

    private val O1 = Regex("^(?:open|launch|start) (.+?)(?: (?:kar|karo|do|de))*$")
    private val O2 = Regex("^(.+?) (?:khol\\w*|chalu|chalao|open|start)(?: (?:kar|karo|do|de|dena))*$")

    private val OPEN_VERBS = Regex("^(khol\\w*|open|chalu|chalao|start|kar|karo|do|de)( (kar|karo|do|de))*$")

    /** The normaliser lower-cases everything; restore the user's capitalisation for text that gets typed or sent. */
    private fun restoreCase(raw: String, payload: String): String {
        val i = raw.lowercase().indexOf(payload.lowercase())
        return if (i >= 0 && i + payload.length <= raw.length) raw.substring(i, i + payload.length).trim() else payload
    }

    private fun parsePronounMessage(t: String, raw: String): Cmd? {
        val rest = R_PRON.find(t)?.groupValues?.get(1) ?: return null
        if (R_PRON_NOTEXT.matches(rest)) return Cmd.WhatsAppToContext(null)
        val text = (R_PRON_AFTER.find(rest) ?: R_PRON_BEFORE.find(rest))?.groupValues?.get(1)?.trim() ?: return null
        if (text.isEmpty() || text == "ek") return Cmd.WhatsAppToContext(null)
        return Cmd.WhatsAppToContext(restoreCase(raw, text))
    }


    private val MSG_LEAD = setOf("message", "msg", "sandesh", "whatsapp", "par", "pe", "per", "mein", "me", "ko", "bhejo", "bhej", "bhejna")
    private val MSG_TRAIL_PHRASES = listOf(
        "bhejna hai", "bhej do", "bhej de", "bhejo", "bhejna", "bhej", "send karo", "send kar do", "send kar", "send",
        "karo", "kar do", "kar de", "kar", "do", "de", "message", "msg", "sandesh", "whatsapp")

    /**
     * Removes assistant/command words that leaked into the payload: "message hello" -> "hello",
     * "par kal milte hain message bhejo" -> "kal milte hain". Never empties a real message to nothing
     * unless it consisted only of command words (then the caller asks "Kya message bhejna hai?").
     */
    internal fun cleanMessageText(text: String): String {
        var w = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        var changed = true
        while (changed && w.isNotEmpty()) {
            changed = false
            if (w.size > 1 && w.first() in MSG_LEAD) { w = w.drop(1); changed = true }
            for (ph in MSG_TRAIL_PHRASES) {
                val pw = ph.split(" ")
                if (w.size > pw.size && w.takeLast(pw.size) == pw) { w = w.dropLast(pw.size); changed = true; break }
            }
        }
        return w.joinToString(" ")
    }

    private fun has(t: String, vararg words: String) = words.any { " $t ".contains(" $it ") }

    fun parse(raw: String): Cmd {
        if (raw.isBlank()) return Cmd.Unknown(raw)
        val t = Normalizer.normalize(raw)
        if (t.isBlank()) return Cmd.Greeting
        if (t in YES) return Cmd.Yes
        if (t in NO) return Cmd.No
        if (t == "band karo" || has(t, "stop", "stop listening", "bye", "good bye", "alvida", "band ho ja")) return Cmd.Stop

        // Typing / dictation (before the WhatsApp block so "message likho" style text is not mistaken for a send)
        if (R_DICTATE.matches(t)) return Cmd.Dictate
        (R_TYPE_A.find(t) ?: R_TYPE_B.find(t) ?: R_TYPE_C.find(t))?.let {
            val payload = it.groupValues[1].trim()
            if (payload.isNotEmpty()) return Cmd.TypeText(restoreCase(raw, payload))
        }
        if (t in SUBMIT_PHRASES) return Cmd.Submit

        // WhatsApp message
        if (has(t, "message", "msg", "sandesh")) {
            parsePronounMessage(t, raw)?.let { return it }
            // "rahul ko whatsapp par kal milte hain message bhejo": payload sits BEFORE the word "message"
            R_WA_NAME_TEXT_MSG.find(t)?.let { nm ->
                val txt = cleanMessageText(nm.groupValues[2])
                if (txt.isNotEmpty() && txt != "whatsapp" && R_WA_EN.find(t) == null)
                    return Cmd.WhatsApp(restoreCase(raw, nm.groupValues[1].trim()), restoreCase(raw, txt))
            }
            val m = R_WA_HINDI.find(t) ?: R_WA_EN.find(t)
            if (m != null) {
                val text = cleanMessageText(m.groupValues[2])
                if (text.isEmpty() || R_VERB_ONLY.matches(text)) return Cmd.MissingArg("Kya message bhejna hai?")
                return Cmd.WhatsApp(restoreCase(raw, m.groupValues[1].trim()), restoreCase(raw, text))
            }
            return Cmd.MissingArg("Kisko aur kya message bhejna hai?")
        }

        R_WA_CHAT.find(t)?.let { return Cmd.WhatsAppOpenChat(restoreCase(raw, it.groupValues[1].trim())) }

        if (has(t, "recent apps", "recent app", "recents", "recent screen", "task switcher")) return Cmd.Recents
        if (has(t, "scroll", "scrol", "skroll")) {
            val down = has(t, "neeche", "niche", "nichey", "nechay", "down")
            val up = has(t, "upar", "oopar", "upper", "up")
            if (down && !up) return Cmd.Scroll(true)
            if (up && !down) return Cmd.Scroll(false)
            return Cmd.MissingArg("Upar scroll karun ya neeche?")
        }
        if (has(t, "refresh", "reload")) return Cmd.Refresh
        if (has(t, "clear", "saaf", "mita", "mitao", "hatao", "delete") && has(t, "text", "likha", "box")) return Cmd.ClearText

        if (has(t, "lock") || t.contains("screen band") || t.contains("phone band")) return Cmd.Lock
        if (has(t, "next reel", "next video", "next short", "swipe up", "reel badlo", "agli reel")) return Cmd.Swipe(true)
        if (has(t, "previous reel", "previous video", "pichli reel", "swipe down")) return Cmd.Swipe(false)
        if (has(t, "go home", "home screen", "home jao")) return Cmd.Home
        if (has(t, "go back", "back jao", "peeche jao", "piche jao", "back kar")) return Cmd.Back

        // Volume (before the settings block so "volume badhao" changes volume while "volume settings kholo" opens settings)
        if (has(t, "volume", "awaaz", "sound") && !has(t, "settings", "setting", "khol", "kholo", "open")) {
            when {
                has(t, "mute", "silent") -> return Cmd.Volume(0)
                has(t, "badhao", "badha", "badhana", "increase", "up", "zyada", "tez", "louder") -> return Cmd.Volume(1)
                has(t, "kam", "ghatao", "ghata", "ghatana", "decrease", "down", "low", "dheere", "halka") -> return Cmd.Volume(-1)
            }
        }

        // Torch / flashlight
        if (has(t, "torch", "flashlight")) {
            return when {
                has(t, "off", "band", "bujhao", "bandh") -> Cmd.Torch(false)
                has(t, "on", "chalu", "jalao", "chalao", "start") -> Cmd.Torch(true)
                else -> Cmd.MissingArg("Torch on karun ya off?")
            }
        }

        // Settings screens
        val kind = when {
            has(t, "wifi", "wi fi") -> "wifi"
            has(t, "bluetooth") -> "bluetooth"
            has(t, "display", "brightness") -> "display"
            has(t, "sound", "volume", "awaaz") -> "sound"
            has(t, "accessibility") -> "accessibility"
            else -> null
        }
        if (kind != null && has(t, "khol", "kholo", "open", "settings", "setting", "on", "off", "chalu", "band")) {
            return Cmd.OpenSettings(kind)
        }

        // YouTube
        if (has(t, "youtube")) {
            Y1.find(t)?.let { return Cmd.YouTubeSearch(it.groupValues[1].trim()) }
            Y3.find(t)?.let { return Cmd.YouTubeSearch(it.groupValues[1].trim()) }
            Y2.find(t)?.let {
                val q = it.groupValues[1].trim()
                if (!OPEN_VERBS.matches(q)) return Cmd.YouTubeSearch(q)
            }
        }

        // Web search
        if (t in setOf("search", "google", "dhundho")) return Cmd.MissingArg("Kya search karna hai?")
        S1.find(t)?.let {
            val q = it.groupValues[1].trim()
            if (!OPEN_VERBS.matches(q)) return Cmd.WebSearch(q)
        }
        S2.find(t)?.let {
            val q = it.groupValues[1].trim()
            if (!OPEN_VERBS.matches(q)) return Cmd.WebSearch(q)
        }

        // Identity
        if (has(t, "tumhara naam", "tera naam", "aapka naam", "your name", "who are you", "tum kaun ho", "aap kaun ho", "tu kaun hai")) return Cmd.AskName
        if (has(t, "mera naam", "my name", "main kaun hoon")) return Cmd.AskUserName

        // Time / date
        if (has(t, "date", "tarikh", "tareekh", "what day", "kaun sa din")) return Cmd.TellDate
        if (has(t, "time", "samay", "baje", "waqt")) return Cmd.TellTime

        // Open app
        (O1.find(t) ?: O2.find(t))?.let {
            val name = it.groupValues[1].trim().removeSuffix(" app").trim()
            if (name.isNotEmpty()) return Cmd.OpenApp(name)
        }

        if (has(t, "thanks", "thank you", "thank", "shukriya", "dhanyavad")) return Cmd.Thanks
        if (has(t, "kaise ho", "how are you", "kya haal", "kaisa hai")) return Cmd.HowAreYou
        if (has(t, "hello", "hi", "namaste", "namaskar") || t == "jarvis") return Cmd.Greeting

        return if (t.split(" ").size >= 2) Cmd.Chat(raw.trim()) else Cmd.Unknown(raw)
    }
}
